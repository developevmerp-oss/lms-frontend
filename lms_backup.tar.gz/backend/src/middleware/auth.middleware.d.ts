import { Request, Response, NextFunction } from 'express';
export interface AuthRequest extends Request {
    user?: {
        id: string;
        role: string;
    };
}
export declare const authenticate: (req: AuthRequest, res: Response, next: NextFunction) => any;
export declare const authorize: (roles: string[]) => (req: AuthRequest, res: Response, next: NextFunction) => any;
//# sourceMappingURL=auth.middleware.d.ts.map