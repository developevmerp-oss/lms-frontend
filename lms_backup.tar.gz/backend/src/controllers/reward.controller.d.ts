import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
export declare const getRewards: (req: Request, res: Response) => Promise<any>;
export declare const createReward: (req: Request, res: Response) => Promise<any>;
export declare const redeemReward: (req: AuthRequest, res: Response) => Promise<any>;
//# sourceMappingURL=reward.controller.d.ts.map