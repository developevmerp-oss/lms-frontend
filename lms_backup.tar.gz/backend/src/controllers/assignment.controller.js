"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reviewSubmission = exports.submitAssignment = exports.createAssignment = void 0;
const express_1 = require("express");
const models_1 = __importDefault(require("../models"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const { Assignment, Submission, User } = models_1.default;
// Create assignment
const createAssignment = async (req, res) => {
    try {
        const { title, description, points, dueDate, courseId } = req.body;
        const assignment = await Assignment.create({ title, description, points, dueDate, courseId });
        res.status(201).json({ message: 'Assignment created', assignment });
    }
    catch (error) {
        console.error('Error creating assignment:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.createAssignment = createAssignment;
// Student submits an assignment
const submitAssignment = async (req, res) => {
    try {
        const { assignmentId } = req.params;
        const { fileUrl } = req.body;
        const studentId = req.user?.id;
        const submission = await Submission.create({ fileUrl, assignmentId, studentId });
        res.status(201).json({ message: 'Assignment submitted', submission });
    }
    catch (error) {
        console.error('Error submitting assignment:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.submitAssignment = submitAssignment;
// Admin reviews and awards points
const reviewSubmission = async (req, res) => {
    try {
        const { submissionId } = req.params;
        const { status, pointsAwarded } = req.body; // status: 'approved' | 'rejected'
        const submission = await Submission.findByPk(submissionId);
        if (!submission)
            return res.status(404).json({ message: 'Submission not found' });
        submission.status = status;
        submission.pointsAwarded = pointsAwarded;
        await submission.save();
        // If approved, update student points and streak
        if (status === 'approved') {
            const student = await User.findByPk(submission.studentId);
            if (student) {
                student.points += pointsAwarded;
                student.streak += 1;
                await student.save();
            }
        }
        res.status(200).json({ message: 'Submission reviewed', submission });
    }
    catch (error) {
        console.error('Error reviewing submission:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.reviewSubmission = reviewSubmission;
//# sourceMappingURL=assignment.controller.js.map