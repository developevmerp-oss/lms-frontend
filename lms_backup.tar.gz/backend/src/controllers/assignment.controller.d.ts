import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
export declare const createAssignment: (req: Request, res: Response) => Promise<any>;
export declare const submitAssignment: (req: AuthRequest, res: Response) => Promise<any>;
export declare const reviewSubmission: (req: Request, res: Response) => Promise<any>;
//# sourceMappingURL=assignment.controller.d.ts.map