import { Request, Response } from 'express';
import db from '../models';
import { AuthRequest } from '../middleware/auth.middleware';

const { User, Course, Submission, Reward } = db;

export const getAdminStats = async (req: AuthRequest, res: Response): Promise<any> => {
  try {
    // Total Students
    const totalStudents = await User.count({ where: { role: 'student' } });

    // Active Courses
    const activeCourses = await Course.count();

    // Pending Assignments
    const pendingAssignments = await Submission.count({ where: { status: 'pending' } });

    // Rewards Distributed (Mocked for now since UserReward pivot doesn't exist yet)
    // Could also just query total rewards available for now or count a redeemed log
    const rewardsDistributed = 0; 

    res.status(200).json({
      totalStudents,
      activeCourses,
      pendingAssignments,
      rewardsDistributed
    });
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

export const getStudentStats = async (req: AuthRequest, res: Response): Promise<any> => {
  try {
    const studentId = req.user?.id;
    if (!studentId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const student = await User.findByPk(studentId);
    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }

    res.status(200).json({
      points: student.points,
      streak: student.streak,
    });
  } catch (error) {
    console.error('Error fetching student stats:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
