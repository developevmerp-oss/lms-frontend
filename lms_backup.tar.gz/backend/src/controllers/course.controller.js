"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addChapter = exports.createCourse = exports.getCourses = void 0;
const express_1 = require("express");
const models_1 = __importDefault(require("../models"));
const { Course, Chapter, Assignment } = models_1.default;
// Get all courses
const getCourses = async (req, res) => {
    try {
        const courses = await Course.findAll({
            include: [
                { model: Chapter, as: 'chapters' },
                { model: Assignment, as: 'assignments' }
            ]
        });
        res.status(200).json(courses);
    }
    catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getCourses = getCourses;
// Create a new course
const createCourse = async (req, res) => {
    try {
        const { title, description, image } = req.body;
        const course = await Course.create({ title, description, image });
        res.status(201).json({ message: 'Course created successfully', course });
    }
    catch (error) {
        console.error('Error creating course:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.createCourse = createCourse;
// Add a chapter to a course
const addChapter = async (req, res) => {
    try {
        const { courseId } = req.params;
        const { title, videoUrl, pdfUrl } = req.body;
        const course = await Course.findByPk(courseId);
        if (!course) {
            return res.status(404).json({ message: 'Course not found' });
        }
        const chapter = await Chapter.create({ title, videoUrl, pdfUrl, courseId });
        res.status(201).json({ message: 'Chapter added successfully', chapter });
    }
    catch (error) {
        console.error('Error adding chapter:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.addChapter = addChapter;
//# sourceMappingURL=course.controller.js.map