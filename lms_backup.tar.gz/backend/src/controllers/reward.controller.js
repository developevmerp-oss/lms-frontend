"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.redeemReward = exports.createReward = exports.getRewards = void 0;
const express_1 = require("express");
const models_1 = __importDefault(require("../models"));
const auth_middleware_1 = require("../middleware/auth.middleware");
const { Reward, User } = models_1.default;
// Get all rewards (store)
const getRewards = async (req, res) => {
    try {
        const rewards = await Reward.findAll();
        res.status(200).json(rewards);
    }
    catch (error) {
        console.error('Error fetching rewards:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.getRewards = getRewards;
// Admin creates a reward
const createReward = async (req, res) => {
    try {
        const { title, description, pointCost, imageUrl } = req.body;
        const reward = await Reward.create({ title, description, pointCost, imageUrl });
        res.status(201).json({ message: 'Reward created', reward });
    }
    catch (error) {
        console.error('Error creating reward:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.createReward = createReward;
// Student redeems a reward
const redeemReward = async (req, res) => {
    try {
        const { rewardId } = req.params;
        const studentId = req.user?.id;
        const reward = await Reward.findByPk(rewardId);
        if (!reward)
            return res.status(404).json({ message: 'Reward not found' });
        const student = await User.findByPk(studentId);
        if (!student)
            return res.status(404).json({ message: 'Student not found' });
        if (student.points < reward.pointCost) {
            return res.status(400).json({ message: 'Not enough points to redeem this reward' });
        }
        // Deduct points
        student.points -= reward.pointCost;
        await student.save();
        // In a real system, you might create a UserReward pivot table to track redemptions
        res.status(200).json({ message: 'Reward redeemed successfully', reward, newPoints: student.points });
    }
    catch (error) {
        console.error('Error redeeming reward:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
exports.redeemReward = redeemReward;
//# sourceMappingURL=reward.controller.js.map