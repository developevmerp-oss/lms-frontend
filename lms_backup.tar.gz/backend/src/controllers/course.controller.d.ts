import { Request, Response } from 'express';
export declare const getCourses: (req: Request, res: Response) => Promise<any>;
export declare const createCourse: (req: Request, res: Response) => Promise<any>;
export declare const addChapter: (req: Request, res: Response) => Promise<any>;
//# sourceMappingURL=course.controller.d.ts.map