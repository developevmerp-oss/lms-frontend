"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_routes_1 = __importDefault(require("./auth.routes"));
const course_routes_1 = __importDefault(require("./course.routes"));
const assignment_routes_1 = __importDefault(require("./assignment.routes"));
const reward_routes_1 = __importDefault(require("./reward.routes"));
const router = (0, express_1.Router)();
router.use('/auth', auth_routes_1.default);
router.use('/courses', course_routes_1.default);
router.use('/assignments', assignment_routes_1.default);
router.use('/rewards', reward_routes_1.default);
exports.default = router;
//# sourceMappingURL=index.js.map