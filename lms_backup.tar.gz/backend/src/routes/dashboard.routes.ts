import { Router } from 'express';
import { getAdminStats, getStudentStats } from '../controllers/dashboard.controller';
import { authenticate, authorize } from '../middleware/auth.middleware';

const router = Router();

// Admin stats route
router.get('/admin', authenticate, authorize(['admin']), getAdminStats);

// Student stats route
router.get('/student', authenticate, authorize(['student']), getStudentStats);

export default router;
