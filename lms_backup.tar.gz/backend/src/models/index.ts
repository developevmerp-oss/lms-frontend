import { Sequelize } from 'sequelize';
import { sequelize } from '../config/database';
import User from './user';
import Course from './course';
import Chapter from './chapter';
import Assignment from './assignment';
import Submission from './submission';
import Reward from './reward';
import Certificate from './certificate';

const db: any = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Add models to db object
db.User = User;
db.Course = Course;
db.Chapter = Chapter;
db.Assignment = Assignment;
db.Submission = Submission;
db.Reward = Reward;
db.Certificate = Certificate;

// Setup associations
Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

export default db;
