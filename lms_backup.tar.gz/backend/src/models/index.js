"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = require("../config/database");
const user_1 = __importDefault(require("./user"));
const course_1 = __importDefault(require("./course"));
const chapter_1 = __importDefault(require("./chapter"));
const assignment_1 = __importDefault(require("./assignment"));
const submission_1 = __importDefault(require("./submission"));
const reward_1 = __importDefault(require("./reward"));
const certificate_1 = __importDefault(require("./certificate"));
const db = {};
db.Sequelize = sequelize_1.Sequelize;
db.sequelize = database_1.sequelize;
// Add models to db object
db.User = user_1.default;
db.Course = course_1.default;
db.Chapter = chapter_1.default;
db.Assignment = assignment_1.default;
db.Submission = submission_1.default;
db.Reward = reward_1.default;
db.Certificate = certificate_1.default;
// Setup associations
Object.keys(db).forEach((modelName) => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});
exports.default = db;
//# sourceMappingURL=index.js.map